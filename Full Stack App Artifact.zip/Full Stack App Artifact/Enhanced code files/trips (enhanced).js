const mongoose = require('mongoose');
require('../models/travlr.js'); // register model
const Model = mongoose.model('trips');
const Trip = require('../models/travlr.js');

// GET: /trips - list all trips
// ADDED sorting so results come back in a cleaner order
// ADDED error handling so the app does not crash if something fails
const tripsList = async (req, res) => {
  try {
    const q = await Model
      .find({})
      .sort({ name: 1 })
      .lean()
      .exec();

    if (!q || q.length === 0) {
      return res
        .status(404)
        .json({ message: 'No trips found' });
    } else {
      return res
        .status(200)
        .json(q);
    }
  } catch (err) {
    return res
      .status(500)
      .json({ message: 'Database error', error: err.message });
  }
};

// GET: /trips/:tripCode - get one trip
// ADDED findOne so only a single trip is returned instead of an array
// ADDED error handling for better reliability
const tripsFindByCode = async (req, res) => {
  try {
    const q = await Model
      .findOne({ code: req.params.tripCode })
      .lean()
      .exec();

    if (!q) {
      return res
        .status(404)
        .json({ message: 'Trip not found' });
    } else {
      return res
        .status(200)
        .json(q);
    }
  } catch (err) {
    return res
      .status(500)
      .json({ message: 'Database error', error: err.message });
  }
};

// POST: /trips - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
// ADDED try/catch so invalid data does not get saved
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = new Trip({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    const q = await newTrip.save();

    return res
      .status(201)
      .json(q);

  } catch (err) {
    return res
      .status(400)
      .json({ message: 'Invalid trip data', error: err.message });
  }
};

// PUT: /trips/:tripCode - Updates a trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client

// and JSON message to the requesting client
// ADDED runValidators so updates still follow schema rules
// ADDED error handling to prevent bad updates
const tripsUpdateTrip = async (req, res) => {

  // Uncomment for debugging
  console.log(req.params);
  console.log(req.body);

  try {
    const q = await Model
      .findOneAndUpdate(
        { code: req.params.tripCode },
        {
          code: req.body.code,
          name: req.body.name,
          length: req.body.length,
          start: req.body.start,
          resort: req.body.resort,
          perPerson: req.body.perPerson,
          image: req.body.image,
          description: req.body.description
        },
        {
          new: true,
          runValidators: true
        }
      )
      .lean()
      .exec();

    if (!q) {
      return res
        .status(404)
        .json({ message: 'Database returned no data' });
    } else {
      return res
        .status(200)
        .json(q);
    }

  } catch (err) {
    return res
      .status(400)
      .json({ message: 'Invalid trip data', error: err.message });
  }
};

// EXPORTS
module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip
};