const mongoose = require('mongoose');

// Define the trip schema
// ADDED validation rules to help keep data clean before storing in the database
const tripSchema = new mongoose.Schema({
  code: { type: String, required: true, index: true, trim: true, minlength: 2, maxlength: 20 },
  name: { type: String, required: true, index: true, trim: true, minlength: 2, maxlength: 100 },
  length: { type: String, required: true, trim: true, maxlength: 50 },
  start: { type: Date, required: true },
  resort: { type: String, required: true, trim: true, maxlength: 100 },
  perPerson: { type: String, required: true, trim: true, maxlength: 30 },
  image: { type: String, required: true, trim: true },
  description: { type: String, required: true, trim: true, maxlength: 500 }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;