// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <limits>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    // even though it is a constant and the compiler buffer overflow checks are on.
    // You need to modify this method to prevent buffer overflow without changing the account_number variable,
    // and its position in the declaration. It must always be directly before the variable used for input.
    // You must notify the user if they entered too much data.

    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";

    // ADDED: Use safer input method that limits input to buffer size
    std::cin.getline(user_input, sizeof(user_input));

    // ADDED: Check if user entered more characters than allowed
    if (std::cin.fail())
    {
        // ADDED: Clear error state and remove extra input from buffer
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        // ADDED: Notify user about invalid input
        std::cout << "Input was too long and was rejected." << std::endl;
        return 1;
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu